"""
The purpose of this function is to create two variable that will be used in my next function. One of these variables
contains a random word taken from a text file filled with words that I made, which is called "word". The other variable
is assigned an empty string at first, until it gets filled with underscores to make it the same length as the random word
taken by the "word" variable. These two variables are then added to a list together, with the "word" variable being the
first index, and the "hidden_word" variable being the second index.
"""

import random #used later to choose a random word from my word list file

def hangman_setup():
    with open("Word_List.txt", "r") as file: #Code learned from the website geeksforgeeks.org, Link to the article: https://www.geeksforgeeks.org/pulling-a-random-word-or-string-from-a-line-in-a-text-file-in-python/
        allText = file.read() #Assigning allText as a variable to read the text file I made using a list of 1000 words
        words = list(map(str, allText.split())) #assigning words as a variable, which is a list of all the words in the text file
        word = random.choice(words) #Variable that is a random word taken from the list assigned to words
        hidden_word = ""  #Variable which has an empty string assigned to it to be used later
        for i in range(len(word)): #For every letter in the random word chosen by the variable "word"...
            hidden_word = hidden_word + "_" #An underscore is added to "hidden_word" for every letter in "word" to make them the same length to be used in my next function
        returnlist = [] #Variable which has an empty list assigned to it
        returnlist.append(word) #Added the random word chosen by the variable "word" to the list
        returnlist.append(hidden_word) #Added the update "hidden_word" variable to the list as well
        return(returnlist) #Return the list to be used in my next function

(hangman_setup()) #Calling the function to work

