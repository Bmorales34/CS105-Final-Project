"""
This function is the main function of my final project, meant to do most of the work involved for the game to work.It
takes the results of the previous function, hangman_setup, and uses them to play the game. The user is supposed to input
a random guess, and if that guess matches up with any of the letters in the "word" variable, then those letters are
added to the "hidden_word" variable in the same positions that they were at in the "word" variable. The updated
"hidden_word" variable is then shown to the user, and they are asked to guess again, repeating the process until they
either fill in "hidden_word" to the point that it's the same as the "word" variable and winning, or failing 7 times and
losing the game. Everytime the user fails a guess, a graphic depicting a hanged man is printed, and the man's body gets
developed the more times the user makes an incorrect guess. For every unique guess the user makes, no matter if it's
correct or not, that letter will be removed from a list containing all the letters of the alphabet, and printed to the
user to show them what they have left to guess. At the end of the game, whether the player wins or loses, they will be
asked if they want to play again. If they do, they will have to enter a lowercase y, and the function will call itself
to repeat the game. If they do not, they will have to enter anything else besides a lowercase y, in which case the process
will be finished using exit, which was imported from the sys module.
"""

from Hangman import hangman_setup #imported my hangman function from my hangman file to be used by the function below
from sys import exit #imported the sys module so I can use exit in the function below

def UI(): #UI function used to actually play the game
    alphabet_list = ["a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z"] #List made up of all the lowercase letters in the alphabet
    user_letter_guess = str(input("Please guess a letter: ")) #Variable which lets the user guess a letter in the word they're trying to solve for
    hangman_setup() #Calling hangman_setup to have it create a list containing a random word chosen from the text file, and a hidden_word that matches its length for later use
    hangman_setup_list = hangman_setup() #Assigning what gets returned by hangman_setup to another list
    word = hangman_setup_list[0] #Assigning the first index of the list as "word" and...
    hidden_word = hangman_setup_list[1] #assigning the second index of the list as "hidden_word".
    hangman_stage_counter = 0 #Assigning a variable to the value 0, which will be used later in the function
    if len(user_letter_guess) != 1 and not word: #If the user guesses something that's longer than one letter, and not the actual word...
        user_letter_guess = str(input("Please enter a single letter: ")) #They are asked to try again
    while hangman_stage_counter < 7: #While the variable hangman_stage_counter remains under the count of 7...
        has_found = False #A variable called has_found is assigned to be False for use later
        for i in range(len(word)): #Checking through every letter in the word...
            if word[i] == user_letter_guess: #if there's a letter in the word is the same as the user's guessed letter...
                if user_letter_guess in alphabet_list: #and if the letter the user guessed is still in the alphabet list...
                    alphabet_list.remove(user_letter_guess) #We remove that letter from the alphabet list to show the user what letters they have left to guess
                hidden_word = hidden_word[:i] + user_letter_guess + hidden_word[i + 1:] #We also replace the underscores in our "hidden_word" variable with the letter guessed, which can be multiple if the letter is in the word multiple times
                print(hidden_word) #We then print the hidden_word to the user to let them see how close they are to filling in the hidden word completely
                print(alphabet_list) #We also print the alphabet list to show them which letters they have left to use to guess
                if hangman_stage_counter == 1: #The following code is used to print a graphic of a hangman as it gets formed more and more
                    print(" |-------|\n |   \n |   \n---") #It gets added onto everytime the user fails to make a correct guess
                elif hangman_stage_counter == 2: # The stage that gets printed for the user depends on the count of the hangman_stage_counter
                    print(" |-------|\n |      😀\n |   \n---") # The stage that the user is on gets printed even if they make a correct guess...
                elif hangman_stage_counter == 3: # To show them how close they are to losing at all times
                    print(" |-------|\n |      😐\n |      |\n---")
                elif hangman_stage_counter == 4:
                    print(" |-------|\n |      😐\n |    🤛|\n---")
                elif hangman_stage_counter == 5:
                    print(" |-------|\n |      😣\n |   🤛-|-🤜\n---")
                elif hangman_stage_counter == 6:
                    print(" |-------|\n |      😣\n |   🤛-|-🤜\n |    🦵\n---")
                elif hangman_stage_counter == 7:
                    print(" |-------|\n |      💀\n |   🤛-|-🤜\n |    🦵🦵\n---")
                has_found = True # The variable has_found changes its value to True if the user has made a correct guess to tell the function it doesn't need to move onto to a part of the code later down below
                if hidden_word == word: #If the user fully guesses the word to the point that the "hidden_word" variable is the same as the "word" variable...
                    print("You win! The correct word was: ", word) #Then the function tells the user they have won, and what the correct word was.
                    play_again = str(input("Would you like to play again? Enter 'y' for yes, or anything else for no: ")) #The function then asks the user if they'd like to play again and gives them the option to input something
                    if play_again == 'y': #If the user inputs a lowercase y, then...
                        UI() #The UI function is called to play the game again
                    elif play_again != 'y': #If the user inputs anything besides a lowercase y...
                        print("Goodbye!") #then the function will say goodbye to the user and...
                        exit() # use exit to terminate the process.
            if user_letter_guess == word: #If the user decides to take a risk and fully guess the word by inputting it as their guess, and it matches the "word" variable, then...
                print("You win! The correct word was: ", word) #The function also tells them that they've won, and what the correct word was.
                play_again = str(input("Would you like to play again? Enter 'y' for yes, or anything else for no: ")) #They are asked if they want to play again or not
                if play_again == 'y': #Same as before. If they enter a lowercase y...
                    UI() #The function calls itself to play the game again
                elif play_again != 'y': #And if they enter anything else...
                    print("Goodbye!")# The function says goodbye
                    exit() #And the process is terminated
        if has_found == False: #If the has_found variable remains with the value of False
            if user_letter_guess in alphabet_list: #The function looks to see if the user_letter_guess is in the alphabet list, and if it is...
                alphabet_list.remove(user_letter_guess) #It is removed from the list
            print("Your guess was not correct. Please try again!") #The function prints a statement telling the user their guess was incorrect
            print(hidden_word) #The current hidden_word is printed to show their progress and to help them with their next guess
            print(alphabet_list) #The alphabet list is printed to show the user what they have left to guess
            hangman_stage_counter = hangman_stage_counter + 1 #The value of the hangman_stage_counter is incremented by 1, which is used later
            if hangman_stage_counter == 1: #These statements are used to tell the user how many times they guessed incorrectly.
                print("You've guessed incorrectly 1 time") #If they've guessed incorrectly 1 time, the statement tells them that
            elif hangman_stage_counter != 1: #If they've guessed incorrectly any number of times other than 1...
                print("You've guessed incorrectly", hangman_stage_counter, "times") #They are told that as well, but with "times" instead of "time".
            if hangman_stage_counter == 1: #The hangman stages are here as well, and the hangman_stage_counter is used to know which to print.
                print(" |-------|\n |   \n |   \n---") #The more the user fails, the higher the value of the hangman_stage_counter gets.
            elif hangman_stage_counter == 2: #This leads to further stages of the hangman being printed graphically for the user to see.
                print(" |-------|\n |      😀\n |   \n---")
            elif hangman_stage_counter == 3:
                print(" |-------|\n |      😐\n |      |\n---")
            elif hangman_stage_counter == 4:
                print(" |-------|\n |      😐\n |    🤛|\n---")
            elif hangman_stage_counter == 5:
                print(" |-------|\n |      😣\n |   🤛-|-🤜\n---")
            elif hangman_stage_counter == 6:
                print(" |-------|\n |      😣\n |   🤛-|-🤜\n |    🦵\n---")
            elif hangman_stage_counter == 7:
                print(" |-------|\n |      💀\n |   🤛-|-🤜\n |    🦵🦵\n---")
            if hangman_stage_counter == 7: #Once the hangman_stage counter reaches 7...
                print("You lose! The correct word was: ", word) #The function tells the user that they have lost the game
                play_again = str(input("Would you like to play again? Enter 'y' for yes, or anything else for no: ")) #They are asked if they want to play again or not
                if play_again == 'y': #If they enter y for yes...
                    UI() #The function is called and the game is played again
                elif play_again != 'y': #If anything besides y is entered...
                    print("Goodbye!") #The function says goodbye to the user...
                    exit() #And the process is terminated
        user_letter_guess = str(input("Please guess a letter, or enter the full word: ")) #Used to make sure the user can input another letter if they guess incorrectly

UI() #Used to call the function and make it run
