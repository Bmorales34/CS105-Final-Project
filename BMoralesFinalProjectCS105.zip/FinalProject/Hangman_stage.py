"""
All the code in this file was created for the purpose of seeing how each stage of the hangman would look, and how I
would arrange them to look the best. It's useless now, and doesn't do anything for the actual hangman game, but I'm
going to save it here anyway to be able to look back and see the steps I took in creating the stages.
"""

hangman_stage_1_noose = "|" #I ended up updating the noose by adding a gallows to it as well, so this is outdated
hangman_stage_2_head = "😀" #I originally wanted to make the faces pop out using an emoji that would pop out the same way the leg emojis down below would, but there was nothing that fit
hangman_stage_3_body = "|" #A line representing the body of the hanged man
hangman_stage_4_head = "😐" # I wanted to add some detail to the game by showing the hangman's emotions changing as the player fails
hangman_stage_4_body = "✋|" #I changed the hand added here to pop out more, and added a dash for an arm
hangman_stage_5_body = "✋|✋" # Added an arm on the other side as well
hangman_stage_6_lower_body = "🦵" # Kept the legs the same in my final version
hangman_stage_7_lower_body = "🦵🦵"# Added another leg for the final stage
hangman_stage_7_head = "😵" #Changed the head in the final version to be a skull emoji to show death