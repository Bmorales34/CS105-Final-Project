This is a near-empty project that you can use
for your CS105 final project.

